# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '56fe766777c918b312da4573c8921f047da75387ef760f3ea800516dd30fe398bce77f514c57608756581a5bc8ba4bb43c6f73c6d9a70d81cf5551299fcd8ae2'