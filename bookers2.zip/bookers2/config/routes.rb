Rails.application.routes.draw do
  
  root to: 'homes#top'
  get "/home/about" => "homes#about"
  get "/" => "homes#top"
  
  devise_for :users
  resources :users, only: [:index, :show, :edit, :update]
  resources :books, only: [:new, :create, :index, :show, :destroy, :edit, :update]
  
end
